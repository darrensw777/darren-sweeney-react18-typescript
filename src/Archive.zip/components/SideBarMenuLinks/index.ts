/* istanbul ignore file */
export { default } from './SideBarMenuLinks';
