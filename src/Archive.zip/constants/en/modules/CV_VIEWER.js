export const CV_VIEWER = {
    DOWNLOAD: "Click here to download a PDF of my CV",
    CONTACT: "Contact me",
    PAGE: "Page",
    OF: "of",
    NEXT: "Next",
    PREVIOUS: "Previous",
};
