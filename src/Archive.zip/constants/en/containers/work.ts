export const WORK_COPY = {
    pageTitle: {
        title: "Work / CV",
        subTitle: "My work, please have a look at my CV below. To download a PDF version, click the link.",
    },
};
