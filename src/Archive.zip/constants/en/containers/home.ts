export const HOME_COPY = {
    pageTitle: {
        title: 'Home',
        subTitle:
            'Father, husband, web developer, singer. Have a look around and send me a message if you want to contact me.',
    },
};
