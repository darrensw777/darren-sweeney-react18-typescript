export const MUSIC_COPY = {
    pageTitle: {
        title: 'Music',
        subTitle:
            "I do, and always have, loved music, and in particular, singing. Have a listen to a few songs I've covered...",
    },
};
