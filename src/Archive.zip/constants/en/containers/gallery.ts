export const GALLERY_COPY = {
    pageTitle: {
        title: 'Gallery',
        subTitle: 'Pictures of me and my favourite people!',
    },
};
