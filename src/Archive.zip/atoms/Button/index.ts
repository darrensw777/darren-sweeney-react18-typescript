/* istanbul ignore file */
export { default } from './Button';
