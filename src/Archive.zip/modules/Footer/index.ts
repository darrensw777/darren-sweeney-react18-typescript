/* istanbul ignore file */
export { default } from './Footer';
