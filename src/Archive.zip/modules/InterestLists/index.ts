/* istanbul ignore file */
export { default } from './InterestLists';
