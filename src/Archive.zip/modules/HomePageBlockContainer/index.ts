/* istanbul ignore file */
export { default } from './HomePageBlockContainer';
