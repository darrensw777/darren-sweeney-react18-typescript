export const companyInfo = {
    name: 'Darren Sweeney',
    docTitlePrefix: 'Darren Sweeney - ',
    siteUrl: 'https://darrensweeney.co.uk/',
};
