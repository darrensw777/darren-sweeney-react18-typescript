export const WHITE = '#fff';

export const PRIMARY_COLOR = '#333';
export const PRIMARY_GREY = '#333';
export const SECONDARY_GREY = '#666';

export const LIGHT_GREY = '#ececec';
export const BORDER_GREY = '#ddd';
