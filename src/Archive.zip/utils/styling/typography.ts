/**
 * Font sizes
 */
export const FONT_SIZE_XL = '1.5em';
export const FONT_SIZE_TITLE = '1.25em';
export const FONT_SIZE_REGULAR = '1em';
export const FONT_SIZE_SMALL = '0.75em';
export const FONT_SIZE_TINY = '0.5em';
